import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Shield, Target, Activity, Terminal, AlertTriangle, 
  CheckCircle, XCircle, Clock, Zap, Lock, Globe,
  ChevronRight, Play, RotateCcw, FileText, History,
  Server, Wifi, Eye, Database, Fingerprint, Radio
} from 'lucide-react';
import { Toaster, toast } from 'react-hot-toast';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

// ─── THEME CONSTANTS ───
const THEME = {
  bg: '#0a0a0f',
  bgElevated: '#111118',
  bgCard: '#16161f',
  border: '#1e1e2e',
  borderHover: '#2a2a3e',
  cyan: '#00d4ff',
  cyanGlow: 'rgba(0, 212, 255, 0.15)',
  green: '#00ff88',
  greenGlow: 'rgba(0, 255, 136, 0.15)',
  red: '#ff3366',
  redGlow: 'rgba(255, 51, 102, 0.15)',
  orange: '#ff6b35',
  purple: '#a855f7',
  yellow: '#fbbf24',
  textPrimary: '#f0f0f5',
  textSecondary: '#8b8b9a',
  textMuted: '#5a5a6a',
  mono: "'JetBrains Mono', monospace"
};

// ─── ANIMATED BACKGROUND COMPONENT ───
const CyberBackground = () => {
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    const newParticles = Array.from({ length: 30 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 3 + 1,
      duration: Math.random() * 20 + 10,
      delay: Math.random() * 5,
      opacity: Math.random() * 0.3 + 0.1
    }));
    setParticles(newParticles);
  }, []);

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      zIndex: 0,
      overflow: 'hidden',
      pointerEvents: 'none'
    }}>
      {/* Grid overlay */}
      <div style={{
        position: 'absolute',
        inset: 0,
        backgroundImage: `linear-gradient(rgba(0, 212, 255, 0.03) 1px, transparent 1px),
                          linear-gradient(90deg, rgba(0, 212, 255, 0.03) 1px, transparent 1px)`,
        backgroundSize: '50px 50px',
        maskImage: 'radial-gradient(circle at center, black 20%, transparent 70%)'
      }} />

      {/* Radial glows */}
      <div style={{
        position: 'absolute',
        top: '10%',
        left: '10%',
        width: '600px',
        height: '600px',
        background: 'radial-gradient(circle, rgba(0, 212, 255, 0.06) 0%, transparent 70%)',
        borderRadius: '50%',
        filter: 'blur(60px)'
      }} />
      <div style={{
        position: 'absolute',
        bottom: '10%',
        right: '10%',
        width: '500px',
        height: '500px',
        background: 'radial-gradient(circle, rgba(168, 85, 247, 0.05) 0%, transparent 70%)',
        borderRadius: '50%',
        filter: 'blur(60px)'
      }} />

      {/* Floating particles */}
      {particles.map(p => (
        <motion.div
          key={p.id}
          style={{
            position: 'absolute',
            width: p.size,
            height: p.size,
            background: THEME.cyan,
            borderRadius: '50%',
            left: `${p.x}%`,
            top: `${p.y}%`,
            opacity: p.opacity
          }}
          animate={{
            y: [0, -100, 0],
            x: [0, 50, -30, 0],
            opacity: [p.opacity, p.opacity * 2, p.opacity]
          }}
          transition={{
            duration: p.duration,
            repeat: Infinity,
            delay: p.delay,
            ease: 'easeInOut'
          }}
        />
      ))}
    </div>
  );
};

// ─── SCANNING TERMINAL EFFECT ───
const TerminalEffect = ({ isScanning }) => {
  const [lines, setLines] = useState([]);
  const commands = [
    'Initializing scanner modules...',
    'Loading port enumeration engine...',
    'Configuring HTTP header analyzer...',
    'Preparing XSS payload database...',
    'Establishing target connection...',
    'Running TCP handshake sequence...',
    'Probing service banners...',
    'Analyzing security headers...',
    'Testing reflection vectors...',
    'Compiling vulnerability report...'
  ];

  useEffect(() => {
    if (!isScanning) {
      setLines([]);
      return;
    }

    let index = 0;
    const interval = setInterval(() => {
      if (index < commands.length) {
        setLines(prev => [...prev, commands[index]]);
        index++;
      } else {
        clearInterval(interval);
      }
    }, 800);

    return () => clearInterval(interval);
  }, [isScanning]);

  if (!isScanning) return null;

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      style={{
        background: 'rgba(0, 0, 0, 0.6)',
        border: `1px solid ${THEME.border}`,
        borderRadius: '12px',
        padding: '1.5rem',
        marginTop: '1.5rem',
        fontFamily: THEME.mono,
        fontSize: '0.8rem'
      }}
    >
      <div style={{ color: THEME.cyan, marginBottom: '0.75rem', fontWeight: 600 }}>
        <Terminal size={14} style={{ marginRight: '0.5rem', verticalAlign: 'middle' }} />
        vulnsec@scanner:~$ sudo ./initiate_scan.sh
      </div>
      {lines.map((line, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          style={{ 
            color: i % 2 === 0 ? THEME.green : THEME.textSecondary,
            padding: '0.25rem 0',
            borderLeft: `2px solid ${i % 2 === 0 ? THEME.green : 'transparent'}`,
            paddingLeft: '0.75rem',
            marginLeft: '-0.75rem'
          }}
        >
          <span style={{ color: THEME.textMuted }}>[{String(i + 1).padStart(2, '0')}]</span> {line}
        </motion.div>
      ))}
      {lines.length > 0 && lines.length < commands.length && (
        <motion.div
          animate={{ opacity: [0, 1, 0] }}
          transition={{ duration: 0.8, repeat: Infinity }}
          style={{ color: THEME.cyan, marginTop: '0.5rem' }}
        >
          _
        </motion.div>
      )}
    </motion.div>
  );
};

// ─── THREAT LEVEL BADGE ───
const ThreatBadge = ({ level }) => {
  const colors = {
    low: { bg: 'rgba(0, 255, 136, 0.1)', text: THEME.green, border: 'rgba(0, 255, 136, 0.3)' },
    medium: { bg: 'rgba(251, 191, 36, 0.1)', text: THEME.yellow, border: 'rgba(251, 191, 36, 0.3)' },
    high: { bg: 'rgba(255, 107, 53, 0.1)', text: THEME.orange, border: 'rgba(255, 107, 53, 0.3)' },
    critical: { bg: 'rgba(255, 51, 102, 0.1)', text: THEME.red, border: 'rgba(255, 51, 102, 0.3)' },
    unknown: { bg: 'rgba(90, 90, 106, 0.1)', text: THEME.textMuted, border: 'rgba(90, 90, 106, 0.3)' }
  };

  const c = colors[level] || colors.unknown;

  return (
    <span style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: '0.4rem',
      padding: '0.35rem 0.9rem',
      background: c.bg,
      color: c.text,
      border: `1px solid ${c.border}`,
      borderRadius: '8px',
      fontSize: '0.75rem',
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '1px'
    }}>
      <Shield size={12} />
      {level}
    </span>
  );
};

// ─── SCANNER MODULE CARD ───
const ScannerCard = ({ scanner, isSelected, onToggle }) => {
  const icons = {
    port: <Wifi size={20} />,
    header: <Shield size={20} />,
    xss: <AlertTriangle size={20} />,
    sql: <Database size={20} />,
    csrf: <Fingerprint size={20} />
  };

  const gradients = {
    port: 'linear-gradient(135deg, #00d4ff, #0088ff)',
    header: 'linear-gradient(135deg, #00ff88, #00cc66)',
    xss: 'linear-gradient(135deg, #ff6b35, #ff3366)',
    sql: 'linear-gradient(135deg, #a855f7, #6366f1)',
    csrf: 'linear-gradient(135deg, #fbbf24, #f59e0b)'
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => onToggle(scanner.id)}
      style={{
        background: isSelected ? THEME.bgCard : 'rgba(22, 22, 31, 0.5)',
        border: `2px solid ${isSelected ? THEME.cyan : THEME.border}`,
        borderRadius: '16px',
        padding: '1.25rem',
        cursor: 'pointer',
        position: 'relative',
        overflow: 'hidden',
        transition: 'all 0.3s'
      }}
    >
      {isSelected && (
        <motion.div
          layoutId="scanner-glow"
          style={{
            position: 'absolute',
            inset: 0,
            background: gradients[scanner.id],
            opacity: 0.08,
            borderRadius: '16px'
          }}
        />
      )}

      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.75rem' }}>
        <div style={{
          width: '40px',
          height: '40px',
          borderRadius: '10px',
          background: gradients[scanner.id],
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'white',
          flexShrink: 0
        }}>
          {icons[scanner.id]}
        </div>
        <div>
          <div style={{ fontWeight: 700, fontSize: '0.95rem' }}>{scanner.name}</div>
          <div style={{ fontSize: '0.75rem', color: THEME.textMuted }}>{scanner.status}</div>
        </div>
      </div>

      <p style={{ fontSize: '0.82rem', color: THEME.textSecondary, lineHeight: 1.5, marginBottom: '0.75rem' }}>
        {scanner.description}
      </p>

      <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
        {scanner.id === 'port' && scanner.ports.map(p => (
          <span key={p} style={{
            padding: '0.2rem 0.5rem',
            background: 'rgba(0, 212, 255, 0.1)',
            color: THEME.cyan,
            borderRadius: '4px',
            fontSize: '0.7rem',
            fontFamily: THEME.mono
          }}>{p}</span>
        ))}
        {scanner.id !== 'port' && (
          <span style={{
            padding: '0.2rem 0.5rem',
            background: 'rgba(0, 212, 255, 0.1)',
            color: THEME.cyan,
            borderRadius: '4px',
            fontSize: '0.7rem',
            fontFamily: THEME.mono
          }}>
            {scanner.id === 'xss' || scanner.id === 'sql' ? `${scanner.payloads} payloads` : `${scanner.headers?.length || 0} headers`}
          </span>
        )}
      </div>

      {isSelected && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          style={{
            position: 'absolute',
            top: '0.75rem',
            right: '0.75rem',
            width: '20px',
            height: '20px',
            borderRadius: '50%',
            background: THEME.green,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <CheckCircle size={14} color={THEME.bg} />
        </motion.div>
      )}
    </motion.div>
  );
};

// ─── RESULT CARD ───
const ResultCard = ({ module, data }) => {
  const [expanded, setExpanded] = useState(false);

  const getModuleIcon = () => {
    switch(module) {
      case 'port': return <Wifi size={18} />;
      case 'header': return <Shield size={18} />;
      case 'xss': return <AlertTriangle size={18} />;
      case 'sql': return <Database size={18} />;
      case 'csrf': return <Fingerprint size={18} />;
      default: return <Activity size={18} />;
    }
  };

  const getModuleColor = () => {
    switch(module) {
      case 'port': return THEME.cyan;
      case 'header': return THEME.green;
      case 'xss': return THEME.orange;
      case 'sql': return THEME.purple;
      case 'csrf': return THEME.yellow;
      default: return THEME.textSecondary;
    }
  };

  const isVulnerable = data?.vulnerable;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      style={{
        background: THEME.bgCard,
        border: `1px solid ${isVulnerable ? 'rgba(255, 51, 102, 0.3)' : THEME.border}`,
        borderRadius: '16px',
        overflow: 'hidden',
        marginBottom: '1rem'
      }}
    >
      <div 
        onClick={() => setExpanded(!expanded)}
        style={{
          padding: '1.25rem',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          cursor: 'pointer',
          borderBottom: expanded ? `1px solid ${THEME.border}` : 'none'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{
            width: '36px',
            height: '36px',
            borderRadius: '10px',
            background: `${getModuleColor()}15`,
            color: getModuleColor(),
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            {getModuleIcon()}
          </div>
          <div>
            <div style={{ fontWeight: 700, fontSize: '0.95rem', textTransform: 'capitalize' }}>
              {module} Scanner
            </div>
            <div style={{ fontSize: '0.8rem', color: THEME.textMuted }}>
              {data?.summary || 'No data available'}
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          {isVulnerable ? (
            <span style={{
              padding: '0.3rem 0.75rem',
              background: 'rgba(255, 51, 102, 0.1)',
              color: THEME.red,
              borderRadius: '6px',
              fontSize: '0.75rem',
              fontWeight: 700
            }}>
              <AlertTriangle size={12} style={{ marginRight: '0.3rem', verticalAlign: 'middle' }} />
              VULNERABLE
            </span>
          ) : (
            <span style={{
              padding: '0.3rem 0.75rem',
              background: 'rgba(0, 255, 136, 0.1)',
              color: THEME.green,
              borderRadius: '6px',
              fontSize: '0.75rem',
              fontWeight: 700
            }}>
              <CheckCircle size={12} style={{ marginRight: '0.3rem', verticalAlign: 'middle' }} />
              SECURE
            </span>
          )}
          <ChevronRight 
            size={18} 
            color={THEME.textMuted}
            style={{ 
              transform: expanded ? 'rotate(90deg)' : 'rotate(0deg)',
              transition: 'transform 0.3s'
            }} 
          />
        </div>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            style={{ padding: '1.25rem' }}
          >
            <pre style={{
              fontFamily: THEME.mono,
              fontSize: '0.78rem',
              lineHeight: 1.6,
              color: THEME.textSecondary,
              background: 'rgba(0, 0, 0, 0.3)',
              padding: '1rem',
              borderRadius: '10px',
              overflow: 'auto',
              maxHeight: '400px'
            }}>
              {JSON.stringify(data, null, 2)}
            </pre>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// ─── MAIN APP COMPONENT ───
export default function App() {
  const [target, setTarget] = useState('');
  const [scanners, setScanners] = useState([]);
  const [selectedModules, setSelectedModules] = useState(['port', 'header', 'xss']);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanResults, setScanResults] = useState(null);
  const [scanHistory, setScanHistory] = useState([]);
  const [activeTab, setActiveTab] = useState('scan');
  const [apiStatus, setApiStatus] = useState('checking');

  // Check API health
  useEffect(() => {
    const checkHealth = async () => {
      try {
        const res = await axios.get(`${API_URL}/health`, { timeout: 5000 });
        if (res.status === 200) {
          setApiStatus('online');
          toast.success('Scanner API connected', { icon: '🟢' });
        }
      } catch {
        setApiStatus('offline');
        toast.error('Scanner API unreachable', { icon: '🔴' });
      }
    };
    checkHealth();
  }, []);

  // Load scanner capabilities
  useEffect(() => {
    const loadCapabilities = async () => {
      try {
        const res = await axios.get(`${API_URL}/api/capabilities`);
        setScanners(res.data.scanners);
      } catch (err) {
        console.error('Failed to load capabilities:', err);
      }
    };
    if (apiStatus === 'online') loadCapabilities();
  }, [apiStatus]);

  // Load history
  useEffect(() => {
    const loadHistory = async () => {
      try {
        const res = await axios.get(`${API_URL}/api/history`);
        setScanHistory(res.data.scans);
      } catch (err) {
        console.error('Failed to load history:', err);
      }
    };
    if (apiStatus === 'online') loadHistory();
  }, [apiStatus, scanResults]);

  const toggleModule = (id) => {
    setSelectedModules(prev => 
      prev.includes(id) 
        ? prev.filter(m => m !== id)
        : [...prev, id]
    );
  };

  const startScan = async () => {
    if (!target.trim()) {
      toast.error('Enter a target URL or IP');
      return;
    }
    if (selectedModules.length === 0) {
      toast.error('Select at least one scanner module');
      return;
    }

    setIsScanning(true);
    setScanProgress(0);
    setScanResults(null);

    try {
      const res = await axios.post(`${API_URL}/api/scan`, {
        target: target.trim(),
        modules: selectedModules
      });

      const scanId = res.data.scan_id;
      toast.success(`Scan initiated: ${scanId}`);

      // Poll for progress
      const pollInterval = setInterval(async () => {
        try {
          const statusRes = await axios.get(`${API_URL}/api/scan/${scanId}/status`);
          setScanProgress(statusRes.data.progress);

          if (statusRes.data.status === 'completed') {
            clearInterval(pollInterval);
            const resultsRes = await axios.get(`${API_URL}/api/scan/${scanId}/results`);
            setScanResults(resultsRes.data);
            setIsScanning(false);

            const threatLevel = resultsRes.data.threat_level;
            if (threatLevel === 'critical') {
              toast.error('Critical threats detected!', { icon: '🔴', duration: 5000 });
            } else if (threatLevel === 'high') {
              toast('High risk vulnerabilities found', { icon: '🟠', duration: 4000 });
            } else if (threatLevel === 'medium') {
              toast('Medium risk issues detected', { icon: '🟡', duration: 3000 });
            } else {
              toast.success('Target appears secure', { icon: '🟢', duration: 3000 });
            }
          }
        } catch (err) {
          clearInterval(pollInterval);
          setIsScanning(false);
          toast.error('Scan failed: ' + err.message);
        }
      }, 1500);

    } catch (err) {
      setIsScanning(false);
      toast.error('Failed to start scan: ' + err.message);
    }
  };

  return (
    <div style={{ minHeight: '100vh', position: 'relative', background: THEME.bg }}>
      <CyberBackground />
      <Toaster position="top-right" toastOptions={{
        style: {
          background: THEME.bgCard,
          color: THEME.textPrimary,
          border: `1px solid ${THEME.border}`,
          fontFamily: 'Inter, sans-serif'
        }
      }} />

      {/* Navigation */}
      <nav style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
        background: 'rgba(10, 10, 15, 0.85)',
        backdropFilter: 'blur(20px)',
        borderBottom: `1px solid ${THEME.border}`,
        padding: '1rem 2rem'
      }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div style={{
              width: '36px',
              height: '36px',
              borderRadius: '10px',
              background: 'linear-gradient(135deg, #00d4ff, #a855f7)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'white'
            }}>
              <Shield size={20} />
            </div>
            <div>
              <div style={{ fontWeight: 800, fontSize: '1.1rem', letterSpacing: '-0.5px' }}>
                VulnSec<span style={{ color: THEME.cyan }}>Scanner</span>
              </div>
              <div style={{ fontSize: '0.7rem', color: THEME.textMuted, fontFamily: THEME.mono }}>
                v2.0.0 | {apiStatus === 'online' ? 
                  <span style={{ color: THEME.green }}>● ONLINE</span> : 
                  <span style={{ color: THEME.red }}>● OFFLINE</span>}
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '0.5rem' }}>
            {[
              { id: 'scan', label: 'Scanner', icon: <Target size={16} /> },
              { id: 'history', label: 'History', icon: <History size={16} /> },
              { id: 'reports', label: 'Reports', icon: <FileText size={16} /> }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  padding: '0.6rem 1.2rem',
                  background: activeTab === tab.id ? 'rgba(0, 212, 255, 0.1)' : 'transparent',
                  color: activeTab === tab.id ? THEME.cyan : THEME.textSecondary,
                  border: `1px solid ${activeTab === tab.id ? 'rgba(0, 212, 255, 0.3)' : 'transparent'}`,
                  borderRadius: '10px',
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  transition: 'all 0.3s',
                  fontFamily: 'Inter, sans-serif'
                }}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main style={{ position: 'relative', zIndex: 1, maxWidth: '1200px', margin: '0 auto', padding: '2rem' }}>

        {/* SCAN TAB */}
        {activeTab === 'scan' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            {/* Hero Section */}
            <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5 }}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  padding: '0.5rem 1rem',
                  background: 'rgba(0, 212, 255, 0.08)',
                  border: '1px solid rgba(0, 212, 255, 0.2)',
                  borderRadius: '100px',
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  color: THEME.cyan,
                  marginBottom: '1.5rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}
              >
                <Radio size={14} />
                Advanced Web Vulnerability Assessment
              </motion.div>

              <h1 style={{
                fontSize: 'clamp(2rem, 5vw, 3.5rem)',
                fontWeight: 900,
                lineHeight: 1.1,
                letterSpacing: '-2px',
                marginBottom: '1rem'
              }}>
                Secure Your Digital<br />
                <span style={{
                  background: 'linear-gradient(135deg, #00d4ff, #a855f7, #ff3366)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent'
                }}>
                  Infrastructure
                </span>
              </h1>

              <p style={{ color: THEME.textSecondary, maxWidth: '500px', margin: '0 auto', fontSize: '1.05rem' }}>
                Multi-vector security scanning with real-time threat analysis and comprehensive reporting.
              </p>
            </div>

            {/* Target Input */}
            <div style={{
              background: THEME.bgCard,
              border: `1px solid ${THEME.border}`,
              borderRadius: '20px',
              padding: '2rem',
              marginBottom: '2rem'
            }}>
              <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem' }}>
                <div style={{ flex: 1, position: 'relative' }}>
                  <Globe size={18} style={{
                    position: 'absolute',
                    left: '1rem',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    color: THEME.textMuted
                  }} />
                  <input
                    type="text"
                    value={target}
                    onChange={(e) => setTarget(e.target.value)}
                    placeholder="Enter target URL or IP (e.g., https://example.com)"
                    style={{
                      width: '100%',
                      padding: '1rem 1rem 1rem 3rem',
                      background: THEME.bg,
                      border: `1px solid ${THEME.border}`,
                      borderRadius: '12px',
                      color: THEME.textPrimary,
                      fontSize: '0.95rem',
                      fontFamily: 'Inter, sans-serif',
                      outline: 'none',
                      transition: 'border-color 0.3s'
                    }}
                    onFocus={(e) => e.target.style.borderColor = THEME.cyan}
                    onBlur={(e) => e.target.style.borderColor = THEME.border}
                    onKeyPress={(e) => e.key === 'Enter' && startScan()}
                  />
                </div>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={startScan}
                  disabled={isScanning || apiStatus !== 'online'}
                  style={{
                    padding: '1rem 2.5rem',
                    background: isScanning ? THEME.border : 'linear-gradient(135deg, #00d4ff, #a855f7)',
                    border: 'none',
                    borderRadius: '12px',
                    color: 'white',
                    fontWeight: 700,
                    fontSize: '0.95rem',
                    cursor: isScanning || apiStatus !== 'online' ? 'not-allowed' : 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    whiteSpace: 'nowrap',
                    opacity: apiStatus !== 'online' ? 0.5 : 1
                  }}
                >
                  {isScanning ? <Activity size={18} className="spin" /> : <Play size={18} />}
                  {isScanning ? 'Scanning...' : 'Initiate Scan'}
                </motion.button>
              </div>

              {/* Progress Bar */}
              {isScanning && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                >
                  <div style={{
                    height: '4px',
                    background: THEME.bg,
                    borderRadius: '2px',
                    overflow: 'hidden',
                    marginBottom: '0.5rem'
                  }}>
                    <motion.div
                      animate={{ width: `${scanProgress}%` }}
                      transition={{ type: 'spring', stiffness: 50 }}
                      style={{
                        height: '100%',
                        background: 'linear-gradient(90deg, #00d4ff, #00ff88)',
                        borderRadius: '2px'
                      }}
                    />
                  </div>
                  <div style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    fontSize: '0.75rem',
                    color: THEME.textMuted,
                    fontFamily: THEME.mono
                  }}>
                    <span>Progress: {scanProgress}%</span>
                    <span>{selectedModules.length} modules active</span>
                  </div>
                </motion.div>
              )}

              <TerminalEffect isScanning={isScanning} />
            </div>

            {/* Scanner Modules */}
            <div style={{ marginBottom: '2rem' }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '1.5rem'
              }}>
                <div>
                  <div style={{
                    fontSize: '0.75rem',
                    fontWeight: 700,
                    color: THEME.cyan,
                    textTransform: 'uppercase',
                    letterSpacing: '2px',
                    marginBottom: '0.5rem'
                  }}>
                    Scanner Modules
                  </div>
                  <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>
                    Select Detection Engines
                  </h2>
                </div>
                <div style={{
                  padding: '0.5rem 1rem',
                  background: 'rgba(0, 212, 255, 0.08)',
                  borderRadius: '8px',
                  fontSize: '0.8rem',
                  color: THEME.cyan,
                  fontFamily: THEME.mono
                }}>
                  {selectedModules.length} selected
                </div>
              </div>

              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
                gap: '1rem'
              }}>
                {scanners.map(scanner => (
                  <ScannerCard
                    key={scanner.id}
                    scanner={scanner}
                    isSelected={selectedModules.includes(scanner.id)}
                    onToggle={toggleModule}
                  />
                ))}
              </div>
            </div>

            {/* Results Section */}
            <AnimatePresence>
              {scanResults && (
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -30 }}
                >
                  <div style={{
                    background: THEME.bgCard,
                    border: `1px solid ${THEME.border}`,
                    borderRadius: '20px',
                    padding: '2rem',
                    marginBottom: '2rem'
                  }}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      marginBottom: '2rem',
                      paddingBottom: '1.5rem',
                      borderBottom: `1px solid ${THEME.border}`
                    }}>
                      <div>
                        <div style={{
                          fontSize: '0.75rem',
                          fontWeight: 700,
                          color: THEME.cyan,
                          textTransform: 'uppercase',
                          letterSpacing: '2px',
                          marginBottom: '0.5rem'
                        }}>
                          Scan Results
                        </div>
                        <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>
                          Assessment Report
                        </h2>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                        <ThreatBadge level={scanResults.threat_level} />
                        <span style={{
                          padding: '0.4rem 1rem',
                          background: 'rgba(0, 212, 255, 0.08)',
                          borderRadius: '8px',
                          fontSize: '0.8rem',
                          color: THEME.cyan,
                          fontFamily: THEME.mono
                        }}>
                          ID: {scanResults.scan_id}
                        </span>
                      </div>
                    </div>

                    {/* Summary Stats */}
                    <div style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(4, 1fr)',
                      gap: '1rem',
                      marginBottom: '2rem'
                    }}>
                      {[
                        { 
                          label: 'Target', 
                          value: scanResults.target,
                          icon: <Globe size={16} />,
                          color: THEME.cyan
                        },
                        { 
                          label: 'Threat Level', 
                          value: scanResults.threat_level.toUpperCase(),
                          icon: <Shield size={16} />,
                          color: scanResults.threat_level === 'critical' ? THEME.red : 
                                 scanResults.threat_level === 'high' ? THEME.orange :
                                 scanResults.threat_level === 'medium' ? THEME.yellow : THEME.green
                        },
                        { 
                          label: 'Findings', 
                          value: scanResults.findings_count,
                          icon: <AlertTriangle size={16} />,
                          color: THEME.red
                        },
                        { 
                          label: 'Modules', 
                          value: Object.keys(scanResults.results || {}).length,
                          icon: <Zap size={16} />,
                          color: THEME.purple
                        }
                      ].map((stat, i) => (
                        <div key={i} style={{
                          background: THEME.bg,
                          border: `1px solid ${THEME.border}`,
                          borderRadius: '12px',
                          padding: '1.25rem',
                          textAlign: 'center'
                        }}>
                          <div style={{
                            width: '36px',
                            height: '36px',
                            borderRadius: '10px',
                            background: `${stat.color}15`,
                            color: stat.color,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            margin: '0 auto 0.75rem'
                          }}>
                            {stat.icon}
                          </div>
                          <div style={{
                            fontSize: '1.1rem',
                            fontWeight: 800,
                            color: stat.color,
                            marginBottom: '0.25rem',
                            fontFamily: THEME.mono
                          }}>
                            {stat.value}
                          </div>
                          <div style={{ fontSize: '0.75rem', color: THEME.textMuted, textTransform: 'uppercase', letterSpacing: '1px' }}>
                            {stat.label}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Detailed Results */}
                    {Object.entries(scanResults.results || {}).map(([module, data]) => (
                      <ResultCard key={module} module={module} data={data} />
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {/* HISTORY TAB */}
        {activeTab === 'history' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div style={{ marginBottom: '2rem' }}>
              <div style={{
                fontSize: '0.75rem',
                fontWeight: 700,
                color: THEME.cyan,
                textTransform: 'uppercase',
                letterSpacing: '2px',
                marginBottom: '0.5rem'
              }}>
                Scan History
              </div>
              <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>
                Previous Assessments
              </h2>
            </div>

            {scanHistory.length === 0 ? (
              <div style={{
                textAlign: 'center',
                padding: '4rem',
                color: THEME.textMuted
              }}>
                <Clock size={48} style={{ marginBottom: '1rem', opacity: 0.5 }} />
                <p>No scan history available</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {scanHistory.map((scan, i) => (
                  <motion.div
                    key={scan.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    style={{
                      background: THEME.bgCard,
                      border: `1px solid ${THEME.border}`,
                      borderRadius: '12px',
                      padding: '1.25rem',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      cursor: 'pointer',
                      transition: 'border-color 0.3s'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.borderColor = THEME.borderHover}
                    onMouseLeave={(e) => e.currentTarget.style.borderColor = THEME.border}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <div style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '10px',
                        background: scan.threat_level === 'critical' ? 'rgba(255, 51, 102, 0.1)' :
                                   scan.threat_level === 'high' ? 'rgba(255, 107, 53, 0.1)' :
                                   scan.threat_level === 'medium' ? 'rgba(251, 191, 36, 0.1)' :
                                   'rgba(0, 255, 136, 0.1)',
                        color: scan.threat_level === 'critical' ? THEME.red :
                               scan.threat_level === 'high' ? THEME.orange :
                               scan.threat_level === 'medium' ? THEME.yellow :
                               THEME.green,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        {scan.threat_level === 'critical' ? <AlertTriangle size={18} /> :
                         scan.threat_level === 'high' ? <AlertTriangle size={18} /> :
                         scan.threat_level === 'medium' ? <Eye size={18} /> :
                         <CheckCircle size={18} />}
                      </div>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: '0.95rem', marginBottom: '0.25rem' }}>
                          {scan.target}
                        </div>
                        <div style={{ fontSize: '0.75rem', color: THEME.textMuted, fontFamily: THEME.mono }}>
                          {scan.id} • {new Date(scan.started).toLocaleString()}
                        </div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <ThreatBadge level={scan.threat_level} />
                      <span style={{
                        padding: '0.3rem 0.75rem',
                        background: scan.findings > 0 ? 'rgba(255, 51, 102, 0.1)' : 'rgba(0, 255, 136, 0.1)',
                        color: scan.findings > 0 ? THEME.red : THEME.green,
                        borderRadius: '6px',
                        fontSize: '0.75rem',
                        fontWeight: 700,
                        fontFamily: THEME.mono
                      }}>
                        {scan.findings} findings
                      </span>
                      <ChevronRight size={18} color={THEME.textMuted} />
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {/* REPORTS TAB */}
        {activeTab === 'reports' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div style={{ marginBottom: '2rem' }}>
              <div style={{
                fontSize: '0.75rem',
                fontWeight: 700,
                color: THEME.cyan,
                textTransform: 'uppercase',
                letterSpacing: '2px',
                marginBottom: '0.5rem'
              }}>
                Reports
              </div>
              <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>
                Generated Reports
              </h2>
            </div>

            <div style={{
              background: THEME.bgCard,
              border: `1px solid ${THEME.border}`,
              borderRadius: '16px',
              padding: '3rem',
              textAlign: 'center',
              color: THEME.textMuted
            }}>
              <FileText size={48} style={{ marginBottom: '1rem', opacity: 0.5 }} />
              <p>Report management coming in v2.1</p>
              <p style={{ fontSize: '0.85rem', marginTop: '0.5rem' }}>
                PDF export, CVSS scoring, and detailed remediation guides
              </p>
            </div>
          </motion.div>
        )}
      </main>

      {/* Footer */}
      <footer style={{
        position: 'relative',
        zIndex: 1,
        textAlign: 'center',
        padding: '2rem',
        borderTop: `1px solid ${THEME.border}`,
        color: THEME.textMuted,
        fontSize: '0.8rem'
      }}>
        <p>
          <Lock size={14} style={{ verticalAlign: 'middle', marginRight: '0.3rem' }} />
          VulnSec Scanner v2.0.0 • Built for ethical security research
        </p>
        <p style={{ marginTop: '0.5rem', fontSize: '0.75rem' }}>
          Always obtain proper authorization before scanning any system • MIT Licensed
        </p>
      </footer>

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .spin {
          animation: spin 1s linear infinite;
        }
      `}</style>
    </div>
  );
}
