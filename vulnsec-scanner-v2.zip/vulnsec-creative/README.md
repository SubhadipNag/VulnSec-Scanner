# 🔒 VulnSec Scanner v2.0

> **Advanced Web Vulnerability Assessment Platform**  
> Built with Flask, React, Docker & Modern Security Engineering

![Version](https://img.shields.io/badge/version-2.0.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Docker](https://img.shields.io/badge/docker-ready-cyan)

---

## 🎯 What You're Getting

A **production-ready**, creatively designed cybersecurity scanner with:

| Feature | Description |
|---------|-------------|
| **5 Scanner Modules** | Port, Header, XSS, SQL Injection, CSRF detection |
| **Real-time Dashboard** | Animated React UI with live progress tracking |
| **Threat Classification** | Automatic CVSS-style risk scoring (Low → Critical) |
| **Docker Deployment** | One-command setup with docker-compose |
| **REST API** | Clean JSON endpoints for programmatic access |
| **Scan History** | Persistent session tracking with visual timeline |
| **Terminal Effects** | Hacker-style scan execution animations |
| **Responsive Design** | Dark cyberpunk theme, mobile-adaptive |

---

## 🏗️ Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   React Frontend │────▶│   Flask API     │────▶│  Scanner Engines│
│   (Port 3000)    │◀────│   (Port 5000)   │◀────│   (Python)      │
└─────────────────┘     └─────────────────┘     └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
    Docker Container         Docker Container        Multi-threaded
    Nginx + Node            Gunicorn + Flask        Port/Header/XSS/
                                                   SQL/CSRF Scanners
```

---

## 🚀 Quick Start (Docker)

### Prerequisites
- Docker Engine 20.10+
- Docker Compose 2.0+

### 1. Clone & Launch
```bash
git clone https://github.com/SubhadipNag/VulnSec-Scanner.git
cd VulnSec-Scanner/vulnsec-creative
docker-compose up --build
```

### 2. Access the Dashboard
- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:5000
- **API Health:** http://localhost:5000/health

### 3. Run a Scan
1. Enter target URL (e.g., `https://example.com`)
2. Select scanner modules (Port, Header, XSS, SQL, CSRF)
3. Click **"Initiate Scan"**
4. Watch real-time terminal effects & progress bar
5. View detailed threat report with expandable findings

---

## 🛠️ Manual Setup (Development)

### Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

### Frontend
```bash
cd frontend
npm install
npm start
```

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Service health check |
| GET | `/api/capabilities` | List available scanners |
| POST | `/api/scan` | Initiate new scan |
| GET | `/api/scan/{id}/status` | Check scan progress |
| GET | `/api/scan/{id}/results` | Get full results |
| GET | `/api/history` | Scan history |
| GET | `/api/reports` | Generated reports |

### Example Scan Request
```bash
curl -X POST http://localhost:5000/api/scan   -H "Content-Type: application/json"   -d '{
    "target": "example.com",
    "modules": ["port", "header", "xss", "sql", "csrf"]
  }'
```

---

## 🎨 Design Features

- **Cyberpunk Dark Theme** — Cyan/purple/green accent gradients
- **Animated Particles** — Floating background elements
- **Hacker Terminal** — Real-time scan execution log
- **Threat Badges** — Color-coded risk indicators
- **Framer Motion** — Smooth page transitions & micro-interactions
- **Lucide Icons** — Consistent cybersecurity iconography
- **Glassmorphism** — Frosted navigation & cards

---

## 🧪 Scanner Modules

### 1. Port Scanner 🔌
- 14 common ports (FTP, SSH, HTTP, HTTPS, MySQL, etc.)
- Multi-threaded TCP handshake
- Service banner detection
- Risk classification per port

### 2. Header Scanner 🛡️
- 7 security headers checked
- CSP, HSTS, X-Frame-Options, etc.
- Weak configuration detection
- Server fingerprinting

### 3. XSS Detector ⚠️
- 12 reflected XSS payloads
- Form & URL parameter testing
- DOM reflection validation
- Severity scoring

### 4. SQL Injection 💉 *(Beta)*
- 8 SQL injection payloads
- Error-based detection
- Boolean-based differential analysis
- Pattern matching for DB errors

### 5. CSRF Checker 🎭 *(Beta)*
- Form token validation
- SameSite cookie checks
- POST method verification
- Remediation recommendations

---

## 📁 Project Structure

```
vulnsec-creative/
├── docker-compose.yml          # Orchestration
├── backend/
│   ├── Dockerfile              # Python container
│   ├── requirements.txt        # Dependencies
│   ├── app.py                  # Flask API
│   └── scanners/
│       ├── __init__.py
│       ├── port_scanner.py     # TCP enumeration
│       ├── header_scanner.py   # HTTP analysis
│       ├── xss_scanner.py      # XSS detection
│       ├── sql_scanner.py      # SQL injection
│       └── csrf_scanner.py     # CSRF validation
└── frontend/
    ├── Dockerfile              # Node/Nginx container
    ├── nginx.conf              # Reverse proxy
    ├── package.json            # React dependencies
    └── src/
        ├── index.js            # Entry point
        └── App.js              # Dashboard (all components)
```

---

## ⚠️ Security Disclaimer

**This tool is for educational and authorized testing only.**

- ✅ Own systems
- ✅ Explicitly authorized targets
- ✅ CTF/lab environments
- ❌ Unauthorized scanning is illegal

---

## 🔮 Future Roadmap

- [ ] PDF Report Export
- [ ] CVSS v3.1 Scoring
- [ ] Real-time WebSocket Updates
- [ ] Authentication & Multi-user
- [ ] CVE Database Integration
- [ ] OWASP Top 10 Mapping
- [ ] AI-powered Risk Analysis
- [ ] Subdomain Enumeration
- [ ] SSL/TLS Certificate Analysis

---

## 📜 License

MIT License — See [LICENSE](LICENSE) for details.

Built with 💜 by **Subhadip Nag** for the cybersecurity community.
