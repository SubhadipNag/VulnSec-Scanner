#!/usr/bin/env python3
import socket
import concurrent.futures
from typing import List, Dict

class PortScanner:
    """Advanced TCP Port Scanner with Service Detection"""

    COMMON_PORTS = {
        21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP",
        53: "DNS", 80: "HTTP", 110: "POP3", 143: "IMAP",
        443: "HTTPS", 3306: "MySQL", 3389: "RDP", 
        5432: "PostgreSQL", 8080: "HTTP-Alt", 8443: "HTTPS-Alt"
    }

    def __init__(self, timeout=3):
        self.timeout = timeout

    def scan_port(self, target: str, port: int) -> Dict:
        """Scan a single port"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(self.timeout)
                result = s.connect_ex((target, port))

                if result == 0:
                    service = self.COMMON_PORTS.get(port, "Unknown")
                    return {
                        "port": port,
                        "state": "open",
                        "service": service,
                        "risk": self._get_risk_level(port)
                    }
                return {"port": port, "state": "closed", "service": None}
        except Exception as e:
            return {"port": port, "state": "error", "error": str(e)}

    def _get_risk_level(self, port: int) -> str:
        """Determine risk level based on port"""
        high_risk = [21, 23, 3389, 3306]  # Telnet, FTP, RDP, MySQL
        medium_risk = [22, 25, 110, 143]   # SSH, SMTP, POP3, IMAP

        if port in high_risk:
            return "high"
        elif port in medium_risk:
            return "medium"
        return "low"

    def scan(self, target: str) -> Dict:
        """Execute full port scan"""
        open_ports = []
        closed_count = 0

        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = {executor.submit(self.scan_port, target, port): port 
                      for port in self.COMMON_PORTS.keys()}

            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result["state"] == "open":
                    open_ports.append(result)
                else:
                    closed_count += 1

        vulnerable = len(open_ports) > 0

        return {
            "scanner": "port",
            "target": target,
            "vulnerable": vulnerable,
            "open_ports": open_ports,
            "closed_count": closed_count,
            "total_scanned": len(self.COMMON_PORTS),
            "summary": f"{len(open_ports)} open ports detected out of {len(self.COMMON_PORTS)} scanned"
        }
