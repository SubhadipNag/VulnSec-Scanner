#!/usr/bin/env python3
import requests
import urllib.parse
from typing import Dict, List
from bs4 import BeautifulSoup

class XSSScanner:
    """Cross-Site Scripting Vulnerability Detector"""

    PAYLOADS = [
        "<script>alert('XSS')</script>",
        "<img src=x onerror=alert('XSS')>",
        "<svg onload=alert('XSS')>",
        "<body onload=alert('XSS')>",
        "<iframe src='javascript:alert(1)'>",
        "<input type='text' value='" onfocus=alert(1) autofocus>",
        "<details open ontoggle=alert(1)>",
        "<marquee onstart=alert(1)>",
        "<a href='javascript:alert(1)'>click</a>",
        "<form action='javascript:alert(1)'><button>submit</button></form>",
        "<object data='javascript:alert(1)'>",
        "<embed src='javascript:alert(1)'>"
    ]

    def __init__(self, timeout=10):
        self.timeout = timeout

    def scan(self, target: str) -> Dict:
        """Test for reflected XSS vulnerabilities"""
        url = target if target.startswith('http') else f"https://{target}"
        findings = []

        try:
            # Get the page to find forms and parameters
            response = requests.get(url, timeout=self.timeout)
            soup = BeautifulSoup(response.text, 'html.parser')

            # Test URL parameters
            parsed = urllib.parse.urlparse(url)
            params = urllib.parse.parse_qs(parsed.query)

            for param_name in params.keys() if params else ['test']:
                for payload in self.PAYLOADS[:6]:  # Test subset for performance
                    test_url = self._inject_param(url, param_name, payload)
                    try:
                        test_response = requests.get(test_url, timeout=self.timeout)
                        if self._check_reflection(test_response.text, payload):
                            findings.append({
                                "type": "reflected",
                                "parameter": param_name,
                                "payload": payload,
                                "evidence": "Payload reflected in response",
                                "severity": "high"
                            })
                    except:
                        continue

            # Test forms
            forms = soup.find_all('form')
            for form in forms[:3]:  # Limit form testing
                action = form.get('action', '')
                method = form.get('method', 'get').lower()
                inputs = form.find_all('input')

                form_data = {}
                for inp in inputs:
                    if inp.get('name'):
                        form_data[inp['name']] = self.PAYLOADS[0]

                if form_data and action:
                    form_url = urllib.parse.urljoin(url, action)
                    try:
                        if method == 'post':
                            form_response = requests.post(form_url, data=form_data, timeout=self.timeout)
                        else:
                            form_response = requests.get(form_url, params=form_data, timeout=self.timeout)

                        if self._check_reflection(form_response.text, self.PAYLOADS[0]):
                            findings.append({
                                "type": "form",
                                "action": action,
                                "payload": self.PAYLOADS[0],
                                "evidence": "Form submission reflected payload",
                                "severity": "high"
                            })
                    except:
                        continue

            vulnerable = len(findings) > 0

            return {
                "scanner": "xss",
                "target": url,
                "vulnerable": vulnerable,
                "findings": findings,
                "forms_tested": len(forms),
                "payloads_tested": len(self.PAYLOADS),
                "summary": f"{len(findings)} potential XSS vectors detected" if vulnerable else "No XSS vulnerabilities detected"
            }

        except requests.RequestException as e:
            return {
                "scanner": "xss",
                "target": url,
                "vulnerable": False,
                "error": str(e),
                "summary": "Connection failed"
            }

    def _inject_param(self, url: str, param: str, value: str) -> str:
        """Inject payload into URL parameter"""
        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qs(parsed.query)
        params[param] = [value]
        new_query = urllib.parse.urlencode(params, doseq=True)
        return urllib.parse.urlunparse(parsed._replace(query=new_query))

    def _check_reflection(self, response_text: str, payload: str) -> bool:
        """Check if payload is reflected in response"""
        # Check for exact or partial reflection
        clean_payload = payload.replace('<', '').replace('>', '')
        return payload in response_text or clean_payload in response_text
