#!/usr/bin/env python3
import requests
import urllib.parse
from typing import Dict, List

class SQLScanner:
    """SQL Injection Vulnerability Detector"""

    PAYLOADS = [
        "' OR '1'='1",
        "' OR '1'='1' --",
        "' OR '1'='1' /*",
        "1' AND 1=1 --",
        "1' AND 1=2 --",
        "1 UNION SELECT null,null,null --",
        "1' UNION SELECT null,null,null --",
        "1; DROP TABLE users --"
    ]

    ERROR_PATTERNS = [
        "sql syntax",
        "mysql_fetch",
        "pg_query",
        "sqlite_query",
        "ORA-",
        "syntax error",
        "unexpected",
        "warning: mysql"
    ]

    def __init__(self, timeout=10):
        self.timeout = timeout

    def scan(self, target: str) -> Dict:
        """Test for SQL injection vulnerabilities"""
        url = target if target.startswith('http') else f"https://{target}"
        findings = []

        try:
            # Get base page for parameter discovery
            response = requests.get(url, timeout=self.timeout)

            # Test URL parameters
            parsed = urllib.parse.urlparse(url)
            base_params = urllib.parse.parse_qs(parsed.query)

            test_params = list(base_params.keys()) if base_params else ['id', 'page', 'cat', 'product']

            for param in test_params:
                for payload in self.PAYLOADS:
                    test_url = self._inject_param(url, param, payload)
                    try:
                        test_response = requests.get(test_url, timeout=self.timeout)

                        # Check for SQL error messages
                        response_lower = test_response.text.lower()
                        for pattern in self.ERROR_PATTERNS:
                            if pattern in response_lower:
                                findings.append({
                                    "type": "error_based",
                                    "parameter": param,
                                    "payload": payload,
                                    "evidence": f"SQL error pattern detected: {pattern}",
                                    "severity": "critical"
                                })
                                break

                        # Check for differential responses (boolean-based)
                        if len(findings) == 0:
                            true_payload = "1' AND 1=1 --"
                            false_payload = "1' AND 1=2 --"

                            true_url = self._inject_param(url, param, true_payload)
                            false_url = self._inject_param(url, param, false_payload)

                            try:
                                true_resp = requests.get(true_url, timeout=self.timeout)
                                false_resp = requests.get(false_url, timeout=self.timeout)

                                if len(true_resp.text) != len(false_resp.text):
                                    findings.append({
                                        "type": "boolean_based",
                                        "parameter": param,
                                        "evidence": "Differential response detected",
                                        "severity": "high"
                                    })
                            except:
                                pass

                    except requests.RequestException:
                        continue

            vulnerable = len(findings) > 0

            return {
                "scanner": "sql",
                "target": url,
                "vulnerable": vulnerable,
                "findings": findings,
                "payloads_tested": len(self.PAYLOADS),
                "summary": f"{len(findings)} SQL injection vectors detected" if vulnerable else "No SQL injection vulnerabilities detected"
            }

        except requests.RequestException as e:
            return {
                "scanner": "sql",
                "target": url,
                "vulnerable": False,
                "error": str(e),
                "summary": "Connection failed"
            }

    def _inject_param(self, url: str, param: str, value: str) -> str:
        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qs(parsed.query)
        params[param] = [value]
        new_query = urllib.parse.urlencode(params, doseq=True)
        return urllib.parse.urlunparse(parsed._replace(query=new_query))
