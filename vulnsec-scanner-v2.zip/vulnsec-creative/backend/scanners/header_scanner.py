#!/usr/bin/env python3
import requests
from typing import Dict, List

class HeaderScanner:
    """HTTP Security Header Analyzer"""

    SECURITY_HEADERS = {
        "Content-Security-Policy": {
            "description": "Prevents XSS and data injection attacks",
            "severity": "high"
        },
        "X-Frame-Options": {
            "description": "Prevents clickjacking attacks",
            "severity": "high"
        },
        "Strict-Transport-Security": {
            "description": "Enforces HTTPS connections",
            "severity": "high"
        },
        "X-Content-Type-Options": {
            "description": "Prevents MIME type sniffing",
            "severity": "medium"
        },
        "Referrer-Policy": {
            "description": "Controls referrer information leakage",
            "severity": "medium"
        },
        "Permissions-Policy": {
            "description": "Restricts browser feature access",
            "severity": "medium"
        },
        "X-XSS-Protection": {
            "description": "Legacy XSS filter (deprecated but checked)",
            "severity": "low"
        }
    }

    def __init__(self, timeout=10):
        self.timeout = timeout

    def scan(self, target: str) -> Dict:
        """Analyze security headers"""
        url = target if target.startswith('http') else f"https://{target}"

        try:
            response = requests.get(url, timeout=self.timeout, allow_redirects=True)
            headers = response.headers

            missing = []
            present = []
            weak = []

            for header, info in self.SECURITY_HEADERS.items():
                if header in headers:
                    value = headers[header]
                    present.append({
                        "header": header,
                        "value": value,
                        "severity": info["severity"]
                    })

                    # Check for weak configurations
                    if header == "X-Frame-Options" and value.lower() not in ["deny", "sameorigin"]:
                        weak.append({"header": header, "issue": "Weak framing policy", "severity": "medium"})

                    if header == "Strict-Transport-Security" and "max-age" not in value.lower():
                        weak.append({"header": header, "issue": "Missing max-age directive", "severity": "medium"})
                else:
                    missing.append({
                        "header": header,
                        "description": info["description"],
                        "severity": info["severity"]
                    })

            vulnerable = len(missing) > 0 or len(weak) > 0

            return {
                "scanner": "header",
                "target": url,
                "vulnerable": vulnerable,
                "missing_headers": missing,
                "present_headers": present,
                "weak_configurations": weak,
                "response_status": response.status_code,
                "server": headers.get('Server', 'Unknown'),
                "summary": f"{len(missing)} missing, {len(weak)} weak configurations detected"
            }

        except requests.RequestException as e:
            return {
                "scanner": "header",
                "target": url,
                "vulnerable": False,
                "error": str(e),
                "summary": "Connection failed"
            }
