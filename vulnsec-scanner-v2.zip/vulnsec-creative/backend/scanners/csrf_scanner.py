#!/usr/bin/env python3
import requests
from bs4 import BeautifulSoup
from typing import Dict, List

class CSRFScanner:
    """Cross-Site Request Forgery Validator"""

    def __init__(self, timeout=10):
        self.timeout = timeout

    def scan(self, target: str) -> Dict:
        """Check for CSRF protection on forms"""
        url = target if target.startswith('http') else f"https://{target}"
        findings = []

        try:
            response = requests.get(url, timeout=self.timeout)
            soup = BeautifulSoup(response.text, 'html.parser')
            forms = soup.find_all('form')

            csrf_tokens = [
                'csrf_token', 'csrfmiddlewaretoken', '_token', 
                'authenticity_token', 'xsrf_token', 'request_token'
            ]

            for form in forms:
                action = form.get('action', '')
                method = form.get('method', 'get').lower()

                # Only check POST forms (GET forms don't typically need CSRF)
                if method != 'post':
                    continue

                inputs = form.find_all('input')
                has_csrf = False
                csrf_field = None

                for inp in inputs:
                    inp_name = inp.get('name', '').lower()
                    if any(token in inp_name for token in csrf_tokens):
                        has_csrf = True
                        csrf_field = inp_name
                        break

                if not has_csrf:
                    findings.append({
                        "form_action": action,
                        "method": method,
                        "issue": "Missing CSRF token",
                        "severity": "medium",
                        "recommendation": "Add CSRF token validation"
                    })
                else:
                    # Check if SameSite cookie attribute is present
                    findings.append({
                        "form_action": action,
                        "method": method,
                        "csrf_field": csrf_field,
                        "issue": "CSRF token present",
                        "severity": "info",
                        "recommendation": "Verify SameSite cookie attributes"
                    })

            vulnerable = any(f["severity"] == "medium" for f in findings)

            return {
                "scanner": "csrf",
                "target": url,
                "vulnerable": vulnerable,
                "forms_analyzed": len(forms),
                "findings": findings,
                "summary": f"{len([f for f in findings if f['severity'] == 'medium'])} forms missing CSRF protection" if vulnerable else "CSRF protection verified"
            }

        except requests.RequestException as e:
            return {
                "scanner": "csrf",
                "target": url,
                "vulnerable": False,
                "error": str(e),
                "summary": "Connection failed"
            }
