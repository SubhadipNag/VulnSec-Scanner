#!/usr/bin/env python3
"""
VulnSec Scanner Backend
Cybersecurity Assessment API with Real-time Capabilities
"""

import os
import json
import uuid
import datetime
from threading import Thread
from flask import Flask, request, jsonify
from flask_cors import CORS
from scanners.port_scanner import PortScanner
from scanners.header_scanner import HeaderScanner
from scanners.xss_scanner import XSSScanner
from scanners.sql_scanner import SQLScanner
from scanners.csrf_scanner import CSRFScanner

app = Flask(__name__)

# CORS Configuration
cors_origins = os.environ.get('CORS_ORIGINS', 'http://localhost:3000').split(',')
CORS(app, origins=cors_origins, supports_credentials=True)

# In-memory scan storage (use Redis in production)
active_scans = {}
scan_history = []

# ─── HEALTH CHECK ───
@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({
        "status": "operational",
        "service": "VulnSec Scanner API",
        "version": "2.0.0",
        "timestamp": datetime.datetime.utcnow().isoformat()
    }), 200

# ─── GET SCANNER CAPABILITIES ───
@app.route('/api/capabilities', methods=['GET'])
def get_capabilities():
    return jsonify({
        "scanners": [
            {
                "id": "port",
                "name": "Port Scanner",
                "description": "TCP port enumeration and service detection",
                "icon": "🔌",
                "ports": [21, 22, 23, 25, 53, 80, 110, 143, 443, 3306, 3389, 5432, 8080, 8443],
                "status": "active"
            },
            {
                "id": "header",
                "name": "Security Headers",
                "description": "HTTP security header analysis",
                "icon": "🛡️",
                "headers": [
                    "Content-Security-Policy",
                    "X-Frame-Options",
                    "Strict-Transport-Security",
                    "X-Content-Type-Options",
                    "Referrer-Policy",
                    "Permissions-Policy",
                    "X-XSS-Protection"
                ],
                "status": "active"
            },
            {
                "id": "xss",
                "name": "XSS Detector",
                "description": "Cross-Site Scripting vulnerability detection",
                "icon": "⚠️",
                "payloads": 12,
                "status": "active"
            },
            {
                "id": "sql",
                "name": "SQL Injection",
                "description": "SQL injection vector detection",
                "icon": "💉",
                "payloads": 8,
                "status": "beta"
            },
            {
                "id": "csrf",
                "name": "CSRF Checker",
                "description": "Cross-Site Request Forgery validation",
                "icon": "🎭",
                "status": "beta"
            }
        ],
        "features": [
            "Real-time scan progress",
            "Multi-threaded execution",
            "JSON report export",
            "CVSS scoring preview",
            "Threat level classification"
        ]
    })

# ─── INITIATE SCAN ───
@app.route('/api/scan', methods=['POST'])
def initiate_scan():
    data = request.get_json()
    target = data.get('target', '').strip()
    selected_modules = data.get('modules', ['port', 'header', 'xss'])

    if not target:
        return jsonify({"error": "Target is required"}), 400

    scan_id = str(uuid.uuid4())[:8]
    scan_data = {
        "id": scan_id,
        "target": target,
        "modules": selected_modules,
        "status": "running",
        "progress": 0,
        "started_at": datetime.datetime.utcnow().isoformat(),
        "results": {},
        "threat_level": "unknown",
        "findings_count": 0
    }

    active_scans[scan_id] = scan_data

    # Run scan asynchronously
    thread = Thread(target=execute_scan, args=(scan_id, target, selected_modules))
    thread.daemon = True
    thread.start()

    return jsonify({
        "scan_id": scan_id,
        "status": "initiated",
        "message": f"Scan initiated for {target}",
        "modules": selected_modules
    }), 202

# ─── SCAN EXECUTION ENGINE ───
def execute_scan(scan_id, target, modules):
    scan = active_scans[scan_id]
    total_modules = len(modules)
    results = {}

    scanners = {
        'port': PortScanner(),
        'header': HeaderScanner(),
        'xss': XSSScanner(),
        'sql': SQLScanner(),
        'csrf': CSRFScanner()
    }

    for idx, module in enumerate(modules):
        if module in scanners:
            try:
                module_results = scanners[module].scan(target)
                results[module] = module_results
            except Exception as e:
                results[module] = {"error": str(e), "status": "failed"}

        scan['progress'] = int(((idx + 1) / total_modules) * 100)
        scan['results'] = results

    # Calculate threat level
    findings = sum(1 for r in results.values() if isinstance(r, dict) and r.get('vulnerable', False))
    scan['findings_count'] = findings

    if findings == 0:
        scan['threat_level'] = "low"
    elif findings <= 2:
        scan['threat_level'] = "medium"
    elif findings <= 4:
        scan['threat_level'] = "high"
    else:
        scan['threat_level'] = "critical"

    scan['status'] = "completed"
    scan['completed_at'] = datetime.datetime.utcnow().isoformat()

    # Save report
    save_report(scan_id, scan)
    scan_history.append(scan)

# ─── GET SCAN STATUS ───
@app.route('/api/scan/<scan_id>/status', methods=['GET'])
def get_scan_status(scan_id):
    if scan_id not in active_scans:
        return jsonify({"error": "Scan not found"}), 404

    scan = active_scans[scan_id]
    return jsonify({
        "scan_id": scan_id,
        "status": scan['status'],
        "progress": scan['progress'],
        "target": scan['target'],
        "threat_level": scan['threat_level'],
        "findings_count": scan['findings_count']
    })

# ─── GET SCAN RESULTS ───
@app.route('/api/scan/<scan_id>/results', methods=['GET'])
def get_scan_results(scan_id):
    if scan_id not in active_scans:
        return jsonify({"error": "Scan not found"}), 404

    scan = active_scans[scan_id]
    return jsonify({
        "scan_id": scan_id,
        "target": scan['target'],
        "status": scan['status'],
        "threat_level": scan['threat_level'],
        "findings_count": scan['findings_count'],
        "started_at": scan['started_at'],
        "completed_at": scan.get('completed_at'),
        "results": scan['results']
    })

# ─── GET SCAN HISTORY ───
@app.route('/api/history', methods=['GET'])
def get_history():
    return jsonify({
        "total": len(scan_history),
        "scans": [
            {
                "id": s['id'],
                "target": s['target'],
                "status": s['status'],
                "threat_level": s['threat_level'],
                "findings": s['findings_count'],
                "started": s['started_at']
            }
            for s in reversed(scan_history[-20:])
        ]
    })

# ─── SAVE REPORT ───
def save_report(scan_id, scan_data):
    report_dir = '/app/reports'
    os.makedirs(report_dir, exist_ok=True)

    filename = f"report_{scan_id}_{datetime.datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
    filepath = os.path.join(report_dir, filename)

    with open(filepath, 'w') as f:
        json.dump(scan_data, f, indent=2)

    return filepath

# ─── GET REPORTS ───
@app.route('/api/reports', methods=['GET'])
def get_reports():
    report_dir = '/app/reports'
    reports = []

    if os.path.exists(report_dir):
        for f in os.listdir(report_dir):
            if f.endswith('.json'):
                reports.append({
                    "filename": f,
                    "created": datetime.datetime.fromtimestamp(
                        os.path.getctime(os.path.join(report_dir, f))
                    ).isoformat()
                })

    return jsonify({"reports": sorted(reports, key=lambda x: x['created'], reverse=True)})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
